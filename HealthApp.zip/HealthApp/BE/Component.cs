﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    //class of components in food 
   public class Component
    {
        public float Sugar { get; set; }
        public float Energy { get; set; }
        public float Fats { get; set; }
        public float Carbohydrate { get; set; }
        public float Vitamins { get; set; }
        public float Protien { get; set; }
        public float Fiber { get; set; }
        public float Water { get; set; }
        public String ndbo { get; set; }


    }
}
