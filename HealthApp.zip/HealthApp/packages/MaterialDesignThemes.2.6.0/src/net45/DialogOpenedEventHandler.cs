﻿namespace MaterialDesignThemes.Wpf
{
    public delegate void DialogOpenedEventHandler(object sender, DialogOpenedEventArgs eventArgs);
}